<div class="pes">
    <div class="pes-body">
        <div class="pes-content">
            <div class="img">
                <img src="_icones/logo.png">
            </div>
            <style>
                
            </style>
            <img src="_icones/instalar.png" class="instalar" onclick="irApp()">
        </div>
    </div>
</div>