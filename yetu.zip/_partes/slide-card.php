<div class="clearfix" style="width:100%;position:relative;margin-bottom:100px">

            <img src="_icones/circle-left.png" id="prev-slide-card" class="circle-left slide-controls">
            <img src="_icones/circle-right.png" id="next-slide-card" class="circle-right slide-controls">
            <ul id="yetu-slide-card" class="gallery list-unstyled cS-hidden">

            </ul>
        </div>