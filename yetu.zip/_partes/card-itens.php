<div class="bloco">
    <div class="card-itens-produto">
          
    </div>

</div>