<div class="clearfix slide-um-clear">

            <img src="_icones/circle-left.png" id="prev-slide-um" class="circle-left slide-controls">
            <img src="_icones/circle-right.png" id="next-slide-um" class="circle-right slide-controls">
            <ul id="yetu-slide-um" class="gallery list-unstyled cS-hidden">
                <img src="_icones/preloader.gif"  class="preloader-img">
            </ul>
        </div>