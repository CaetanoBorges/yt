    <link rel="stylesheet" href="_arq/bootstrap.min.css">
    <link rel="stylesheet" href="_arq/lightslider.css">
    <link rel="stylesheet" href="_css/one.css">
    <link rel="stylesheet" href="_css/header.css">
    <link rel="stylesheet" href="_css/pes.css">
    <link rel="stylesheet" href="_css/slide.css">
    <link rel="stylesheet" href="_css/card-itens.css">
    <link rel="stylesheet" href="_css/slide-sugestao.css">
    <link rel="stylesheet" href="_css/cesto.css">
    <link rel="stylesheet" href="_css/produto.css">

    <link rel="icon" href="_icones/ico.png" type="image/png" />
    <link rel="manifest" href="manifest.json">