<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include("_partes/css.php") ?>
    <title>A caminho</title>
</head>
<style>
    .acaminho{width: 709px;display: block;margin: 50px auto;}
    .dispensa{width: 378px;display: block;margin: 100px auto 40px auto;}
</style>
<body>
    <?php
        include("_partes/header.php");
     ?>


    <div class="yetu-body">
        <img src="_icones/a-caminho.png" class="acaminho">

        <img src="_icones/dispensa-familia.png" class="dispensa">
    </div>
     
           
    <?php
        include("_partes/pes.php");
    ?>

    <?php include("_partes/script.php") ?>

    
     <script>
       
     </script>
</body>
</html>