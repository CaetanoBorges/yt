var tbCarrinho = localforage.createInstance({
    name: "carrinho"
});
var tbProduto = localforage.createInstance({
    name: "produto"
});
var tbUser = localforage.createInstance({
    name: "usuario"
});
var tbSugestoes = localforage.createInstance({
    name: "sugestoes"
});
var tbCompras = localforage.createInstance({
    name: "compras"
});
var tbCategorias = localforage.createInstance({
    name: "categorias"
});
var tbSlide = localforage.createInstance({
    name: "slide"
});